"""Performance Evaluation System"""
from agents.base_agent import BaseAgent
from utils.logger import setup_logger
from typing import Dict
import json

logger = setup_logger(__name__)

class PerformanceEvaluator(BaseAgent):
    """Evaluates quality of each simulation cycle"""
    
    def __init__(self):
        super().__init__("Evaluator")
    
    def get_system_prompt(self) -> str:
        return """You are a Quality Assurance and Performance Evaluation expert.

Your responsibilities:
1. Assess the quality of strategic planning
2. Evaluate task breakdown clarity and feasibility
3. Assess implementation plan technical soundness
4. Provide constructive feedback
5. Identify areas for improvement
6. Score overall performance

Guidelines:
- Be objective and fair in assessment
- Consider industry best practices
- Look for alignment between strategy, tasks, and implementation
- Identify gaps and inconsistencies
- Provide actionable feedback for improvement
- Use a 0-10 scale for all scores

Format your response as a structured evaluation report."""
    
    def evaluate_cycle(self, cycle_data: Dict) -> Dict:
        """Evaluate the complete cycle"""
        
        logger.info(f"Evaluating cycle {cycle_data['cycle']}")
        
        stages_text = json.dumps(
            {k: v for k, v in cycle_data['stages'].items() if k != 'evaluation'},
            indent=2,
            default=str
        )
        
        prompt = f"""Evaluate the quality and effectiveness of this simulation cycle:

GOAL:
{cycle_data['user_goal']}

STRATEGY:
{stages_text}

Provide your evaluation in the following JSON format:
{{
    "cycle_number": {cycle_data['cycle']},
    "overall_score": "Score from 0-10",
    "scores": {{
        "strategy_quality": "Score 0-10: Is the strategy clear, realistic, and well-reasoned?",
        "task_clarity": "Score 0-10: Are tasks well-defined, specific, and actionable?",
        "task_feasibility": "Score 0-10: Are tasks realistic and achievable?",
        "implementation_quality": "Score 0-10: Is the implementation plan technically sound?",
        "risk_assessment": "Score 0-10: Are risks identified and mitigations appropriate?",
        "alignment": "Score 0-10: Do strategy, tasks, and implementation align well?"
    }},
    "strengths": [
        "Strength 1: Explanation",
        "Strength 2: Explanation"
    ],
    "areas_for_improvement": [
        "Area 1: Specific suggestion for improvement",
        "Area 2: Specific suggestion for improvement"
    ],
    "critical_feedback": "Any critical issues that need addressing",
    "lessons_learned": [
        "Lesson 1: What we learned",
        "Lesson 2: What we learned"
    ],
    "recommendations": [
        "Recommendation 1 for next cycle",
        "Recommendation 2 for next cycle"
    ]
}}"""
        
        response = self.call_api(prompt, temperature=0.5, max_tokens=2000)
        
        try:
            evaluation = json.loads(response)
            # Calculate numeric overall score
            if isinstance(evaluation.get("overall_score"), str):
                try:
                    score = float(evaluation["overall_score"].split()[0])
                    evaluation["score"] = score
                except (ValueError, IndexError):
                    evaluation["score"] = 5.0
            else:
                evaluation["score"] = float(evaluation.get("overall_score", 5.0))
        
        except json.JSONDecodeError:
            logger.warning("Failed to parse evaluation as JSON, returning raw response")
            evaluation = {
                "raw_response": response,
                "score": 5.0
            }
        
        logger.info(f"Cycle {cycle_data['cycle']} evaluation complete. Score: {evaluation.get('score', 'N/A')}")
        return evaluation