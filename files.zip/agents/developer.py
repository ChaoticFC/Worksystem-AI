"""Developer Agent - Implementation Planning"""
from agents.base_agent import BaseAgent
from typing import Dict
import json

class Developer(BaseAgent):
    """Developer Agent responsible for implementation planning"""
    
    def __init__(self):
        super().__init__("Developer")
    
    def get_system_prompt(self) -> str:
        return """You are the Lead Developer of an AI-native company.

Your responsibilities:
1. Create detailed technical implementation plans
2. Define architecture and technical approach
3. Identify technical requirements and dependencies
4. Plan testing and quality assurance strategy
5. Assess and track technical debt
6. Consider scalability and performance

Guidelines:
- Be technically thorough and practical
- Consider edge cases and failure scenarios
- Define clear acceptance criteria
- Plan for testing at each level
- Be realistic about technical constraints
- Consider future maintainability

Format your response as a detailed technical specification."""
    
    def plan_implementation(
        self, 
        tasks: Dict, 
        memory_context: str = ""
    ) -> Dict:
        """Create detailed implementation plan"""
        
        self.logger.info("Planning implementation")
        
        tasks_text = json.dumps(tasks, indent=2) if isinstance(tasks, dict) else str(tasks)
        
        prompt = f"""Create a detailed implementation plan for these tasks:

TASKS:
{tasks_text}

ORGANIZATIONAL CONTEXT:
{memory_context if memory_context else "Standard implementation"}

Provide your response in the following JSON format:
{{
    "technical_approach": "High-level technical strategy",
    "architecture": {{
        "components": ["Component 1", "Component 2"],
        "data_flow": "Description of data flow",
        "integration_points": ["Integration point 1", "Integration point 2"]
    }},
    "implementation_phases": [
        {{
            "phase": "Phase 1",
            "focus": "What this phase accomplishes",
            "technical_tasks": ["Technical task 1", "Technical task 2"],
            "deliverables": ["Deliverable 1", "Deliverable 2"],
            "duration": "Estimated duration"
        }}
    ],
    "technology_stack": ["Technology 1", "Technology 2"],
    "testing_strategy": {{
        "unit_tests": "Approach to unit testing",
        "integration_tests": "Approach to integration testing",
        "end_to_end_tests": "Approach to e2e testing",
        "coverage_target": "Target test coverage percentage"
    }},
    "technical_debt": {{
        "identified_items": ["Debt item 1", "Debt item 2"],
        "mitigation_plan": "How we'll address technical debt",
        "priority": "High/Medium/Low"
    }},
    "risks_and_mitigation": [
        {{
            "risk": "Technical risk description",
            "probability": "High/Medium/Low",
            "mitigation": "How we'll mitigate this risk"
        }}
    ],
    "performance_considerations": "Scalability, performance targets",
    "security_considerations": "Security approach and measures",
    "acceptance_criteria": ["Criteria 1", "Criteria 2"]
}}"""
        
        response = self.call_api(prompt, temperature=0.5, max_tokens=3000)
        
        try:
            implementation = json.loads(response)
        except json.JSONDecodeError:
            self.logger.warning("Failed to parse implementation as JSON, returning raw response")
            implementation = {"raw_response": response}
        
        self.logger.info("Implementation plan created successfully")
        return implementation