"""Base agent class"""
from abc import ABC, abstractmethod
from utils.api_client import APIClient
from utils.logger import setup_logger
from typing import Dict, Any

logger = setup_logger(__name__)

class BaseAgent(ABC):
    """Base class for all agents"""
    
    def __init__(self, role: str):
        self.role = role
        self.api_client = APIClient()
        self.logger = setup_logger(f"agent.{role.lower()}")
    
    @abstractmethod
    def get_system_prompt(self) -> str:
        """Return role-specific system prompt"""
        pass
    
    def call_api(
        self, 
        prompt: str, 
        temperature: float = 0.7,
        max_tokens: int = 2000
    ) -> str:
        """Call API with role-specific system prompt"""
        self.logger.info(f"{self.role} calling API")
        
        system_prompt = self.get_system_prompt()
        response = self.api_client.call(
            system_prompt=system_prompt,
            user_message=prompt,
            temperature=temperature,
            max_tokens=max_tokens
        )
        
        self.logger.info(f"{self.role} received response")
        return response