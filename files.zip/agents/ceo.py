"""CEO Agent - Strategic Planning"""
from agents.base_agent import BaseAgent
from typing import Dict
import json

class CEO(BaseAgent):
    """CEO Agent responsible for strategic planning"""
    
    def __init__(self):
        super().__init__("CEO")
    
    def get_system_prompt(self) -> str:
        return """You are the Chief Executive Officer of an AI-native company.

Your responsibilities:
1. Analyze user goals strategically
2. Define organizational direction
3. Identify key priorities and success metrics
4. Consider long-term implications
5. Balance innovation with execution

Guidelines:
- Think strategically but remain grounded in reality
- Consider resource constraints
- Identify potential risks early
- Define clear success criteria
- Be concise and actionable

Format your response as a structured strategic plan."""
    
    def generate_strategy(self, user_goal: str, memory_context: str = "") -> Dict:
        """Generate strategic plan from user goal"""
        
        self.logger.info(f"Generating strategy for goal: {user_goal}")
        
        prompt = f"""Analyze this user goal and create a strategic plan:

USER GOAL:
{user_goal}

ORGANIZATIONAL CONTEXT:
{memory_context if memory_context else "This is a new initiative"}

Provide your response in the following JSON format:
{{
    "vision": "Long-term vision (1-2 sentences)",
    "mission": "Specific mission for this goal (1-2 sentences)",
    "key_objectives": ["objective 1", "objective 2", "objective 3"],
    "success_metrics": ["metric 1", "metric 2", "metric 3"],
    "timeline": "Estimated timeline",
    "key_risks": ["risk 1", "risk 2"],
    "resource_requirements": "Brief overview of required resources",
    "confidence_level": "High/Medium/Low with justification"
}}"""
        
        response = self.call_api(prompt, temperature=0.7, max_tokens=1500)
        
        try:
            strategy = json.loads(response)
        except json.JSONDecodeError:
            self.logger.warning("Failed to parse strategy as JSON, returning raw response")
            strategy = {"raw_response": response}
        
        self.logger.info("Strategy generated successfully")
        return strategy