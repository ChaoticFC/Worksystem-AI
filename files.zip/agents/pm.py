"""Project Manager Agent - Task Breakdown"""
from agents.base_agent import BaseAgent
from typing import Dict, List
import json

class ProjectManager(BaseAgent):
    """Project Manager Agent responsible for task breakdown"""
    
    def __init__(self):
        super().__init__("Project Manager")
    
    def get_system_prompt(self) -> str:
        return """You are the Project Manager of an AI-native company.

Your responsibilities:
1. Break down strategies into actionable tasks
2. Define task dependencies and sequencing
3. Estimate effort and resources
4. Create realistic timelines
5. Identify blockers and dependencies

Guidelines:
- Be practical and detail-oriented
- Consider realistic effort estimation
- Define clear success criteria for each task
- Account for dependencies between tasks
- Provide step-by-step execution plan

Format your response as a structured project plan with tasks."""
    
    def break_down_tasks(
        self, 
        strategy: Dict, 
        memory_context: str = ""
    ) -> Dict:
        """Break down strategy into specific tasks"""
        
        self.logger.info("Breaking down strategy into tasks")
        
        strategy_text = json.dumps(strategy, indent=2) if isinstance(strategy, dict) else str(strategy)
        
        prompt = f"""Break down this strategic plan into concrete, actionable tasks:

STRATEGIC PLAN:
{strategy_text}

ORGANIZATIONAL CONTEXT:
{memory_context if memory_context else "Standard execution"}

Provide your response in the following JSON format:
{{
    "project_name": "Project name",
    "total_tasks": "Number of tasks",
    "estimated_duration": "Total duration",
    "tasks": [
        {{
            "task_id": "TASK-001",
            "title": "Task title",
            "description": "Detailed description",
            "dependencies": ["TASK-000 or none"],
            "effort_estimate": "Effort in hours/days",
            "priority": "High/Medium/Low",
            "success_criteria": ["criteria 1", "criteria 2"],
            "assignee_role": "Developer/Designer/etc",
            "estimated_start": "When this task can start",
            "estimated_end": "When this task should complete"
        }}
    ],
    "critical_path": ["TASK-001", "TASK-002"],
    "risks": ["risk 1", "risk 2"],
    "assumptions": ["assumption 1", "assumption 2"]
}}"""
        
        response = self.call_api(prompt, temperature=0.7, max_tokens=2500)
        
        try:
            tasks = json.loads(response)
        except json.JSONDecodeError:
            self.logger.warning("Failed to parse tasks as JSON, returning raw response")
            tasks = {"raw_response": response}
        
        self.logger.info("Tasks created successfully")
        return tasks