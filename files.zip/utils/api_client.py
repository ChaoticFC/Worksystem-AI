"""OpenAI API Client with error handling"""
import openai
from config import Config
from utils.logger import setup_logger
from typing import Optional, Dict, List
import time

logger = setup_logger(__name__)

class APIClient:
    """Wrapper around OpenAI API with retry logic"""
    
    def __init__(self):
        openai.api_key = Config.OPENAI_API_KEY
        self.model = Config.OPENAI_MODEL
        self.max_retries = 3
        self.retry_delay = 2
    
    def call(
        self, 
        system_prompt: str, 
        user_message: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None
    ) -> str:
        """Call OpenAI API with retry logic"""
        
        if temperature is None:
            temperature = Config.OPENAI_TEMPERATURE
        if max_tokens is None:
            max_tokens = Config.OPENAI_MAX_TOKENS
        
        for attempt in range(self.max_retries):
            try:
                logger.info(f"API call attempt {attempt + 1}/{self.max_retries}")
                
                response = openai.ChatCompletion.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_message}
                    ],
                    temperature=temperature,
                    max_tokens=max_tokens,
                    timeout=30
                )
                
                content = response.choices[0].message.content
                logger.info("API call successful")
                return content
            
            except openai.error.RateLimitError as e:
                logger.warning(f"Rate limit error: {e}")
                if attempt < self.max_retries - 1:
                    wait_time = self.retry_delay * (2 ** attempt)
                    logger.info(f"Waiting {wait_time} seconds before retry...")
                    time.sleep(wait_time)
                else:
                    logger.error("Max retries exceeded for rate limit")
                    raise
            
            except openai.error.APIError as e:
                logger.error(f"API error: {e}")
                if attempt < self.max_retries - 1:
                    wait_time = self.retry_delay * (2 ** attempt)
                    logger.info(f"Waiting {wait_time} seconds before retry...")
                    time.sleep(wait_time)
                else:
                    logger.error("Max retries exceeded for API error")
                    raise
            
            except openai.error.AuthenticationError as e:
                logger.error(f"Authentication error: {e}")
                raise ValueError("Invalid OpenAI API key")
            
            except Exception as e:
                logger.error(f"Unexpected error: {e}")
                raise
        
        raise RuntimeError("Failed to get API response after retries")
    
    def call_with_context(
        self,
        system_prompt: str,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None
    ) -> str:
        """Call API with message history context"""
        
        if temperature is None:
            temperature = Config.OPENAI_TEMPERATURE
        if max_tokens is None:
            max_tokens = Config.OPENAI_MAX_TOKENS
        
        for attempt in range(self.max_retries):
            try:
                logger.info(f"API call with context, attempt {attempt + 1}/{self.max_retries}")
                
                response = openai.ChatCompletion.create(
                    model=self.model,
                    messages=[{"role": "system", "content": system_prompt}] + messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    timeout=30
                )
                
                content = response.choices[0].message.content
                logger.info("API call successful")
                return content
            
            except (openai.error.RateLimitError, openai.error.APIError) as e:
                logger.warning(f"Error during API call: {e}")
                if attempt < self.max_retries - 1:
                    wait_time = self.retry_delay * (2 ** attempt)
                    logger.info(f"Waiting {wait_time} seconds before retry...")
                    time.sleep(wait_time)
                else:
                    raise
            
            except openai.error.AuthenticationError as e:
                logger.error(f"Authentication error: {e}")
                raise ValueError("Invalid OpenAI API key")
        
        raise RuntimeError("Failed to get API response after retries")